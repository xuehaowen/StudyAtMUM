import plotly
import json
#plotly.offline.init_notebook_mode(connected=True)
#import plotly.offline as py
import plotly.plotly as py
import plotly.graph_objs as go
import pandas as pd
import numpy as np

from plotly import tools

class PlotlyOpreator:
    tools.set_credentials_file(username='HuiXiubao', api_key='o4NEKoULsCHaBXrsLixE')
    mapbox_access_token = "pk.eyJ1IjoiYmFvYmFvbWFwYm94IiwiYSI6ImNqaGNjcDVibzBiamMzNnBpMnFhN2V4NmgifQ.uBlB3JEU0iOEzugcNJ_o2Q"

    def __init__(self):
     	print("__init__")

    def __del__(self):
     	print("__del__")

    def draw_station_map(self,chat_dict):
        print("Begin draw stations map......")
    	data_lat = chat_dict['lat']
    	data_lon = chat_dict['lon']
    	data_name = chat_dict['names']

        data =[
            go.Scattermapbox(
                lat=data_lat,
                lon=data_lon,
                mode='markers',
                marker=dict(
                    size=9
                ),
                text=data_name,
            )
        ]

        layout = go.Layout(
            autosize=True,
            hovermode='closest',
            mapbox=dict(
                accesstoken=self.mapbox_access_token,
                bearing=0,
                center=dict(
                    lat=data_lat[0],
                    lon=data_lon[0]
                ),
                pitch=0,
                zoom=10
            ),
        )

        fig = dict(data=data, layout=layout)
        py.plot(fig, filename='Multiple Mapbox')


    def draw_caculate_chat(self,chat_dict):
        print("Begin draw stations info chat......")
        trace = go.Table(
        header=dict(values=['StationId', 'Name','num_bi_ava','num_bi_dis','num_do_ava','capacity','num_do_dis','lat','log']),

        cells=dict(values=[chat_dict['stationid'],
                            chat_dict['name'],
                            chat_dict['num_bi_ava'],
                            chat_dict['num_bi_dis'],
                            chat_dict['num_do_ava'],
                            chat_dict['num_do_dis'],
                            chat_dict['capacity'],
                            chat_dict['lat'],
                            chat_dict['lon']
                            ])
        )
        data = [trace]
        py.plot(data, filename = 'basic_table')

    def draw_top20_dis_rate(self,dict):
        print("Begin draw top20 disable rate bar chat......")
        names = dict['names']
        rates = dict['rates']
        data = [go.Bar(
            x=names,
            y=rates
        )]
        py.plot(data, filename='basic-bar')

if __name__== '__main__':
     	print("__main__")
