from pyspark import SparkContext, SparkConf
from pyspark.sql import functions

from pyspark.sql.types import StructType
from pyspark.sql.types import StructField
from pyspark.sql.types import StringType
from pyspark.sql.types import IntegerType
from pyspark.sql.types import DoubleType
from pyspark.sql import HiveContext
from Bike_Stream_To_Plotly import PlotlyOpreator

def getHiveContextInstance(sparkContext):
    if ('hiveContextSingletonInstance' not in globals()):
        globals()['hiveContextSingletonInstance'] = HiveContext(sparkContext)
        globals()['hiveContextSingletonInstance'].setConf("hive.metastore.uris", "thrift://127.0.0.1:9083")
    return globals()['hiveContextSingletonInstance']


class HiveOpreator:

    def __init__(self):
        self.sqlContext = getHiveContextInstance(SparkContext(appName="myProject"))
        self.sqlContext.sql("show databases").show()
        self.sqlContext.sql("show tables").show()
        print("__init__")

    def __del__(self):
     	print("__del__")

    def read_all_from_hive(self):
        # Read from Hive
        record_dict = {}
        stat_names = []
        stat_ids = []
        num_bi_avas = []
        num_bi_diss = []
        num_do_avas = []
        num_do_diss = []
        lats = []
        logs = []
        capacitys = []

        df_load = self.sqlContext.sql('SELECT distinct(id),name,lat,lon,capacity,bike_ava,bike_dis,dock_ava,dock_dis FROM sharedbikes').collect()
        for row in df_load:
            stat_ids.append(row[0])
            stat_names.append(row[1])
            lats.append(row[2])
            logs.append(row[3])
            capacitys.append(row[4])
            num_bi_avas.append(row[5])
            num_bi_diss.append(row[6])
            num_do_avas.append(row[7])
            num_do_diss.append(row[8])

        record_dict['stationid'] = stat_ids
        record_dict['name'] = stat_names
        record_dict['num_bi_ava'] = num_bi_avas
        record_dict['num_bi_dis'] = num_bi_diss
        record_dict['num_do_ava'] = num_do_avas
        record_dict['num_do_dis'] = num_do_diss
        record_dict['capacity'] = capacitys
        record_dict['lat'] = lats
        record_dict['lon'] = logs
        return record_dict

    def read_locations_from_hive(self):
        stat_names = []
        lats = []
        lons = []
        dict = {}
        df_load = self.sqlContext.sql('SELECT distinct(id),name,lat,lon FROM sharedbikes').collect()

        for rate in df_load:
            stat_names.append(rate[1])
            lats.append(rate[2])
            lons.append(rate[3])

        dict['names'] = stat_names
        dict['lat'] = lats
        dict['lon'] = lons
        return dict

    def read_usereate_top20_from_hive(self):
        stat_names = []
        ratelist = []
        df = self.sqlContext.sql('SELECT distinct(id),name,capacity,bike_dis FROM sharedbikes')
        df.show()
        df = df.withColumn('dis_rate', df.bike_dis/df.capacity)
        rates = df.sort(df.dis_rate.desc()).take(10)
        dict  = {}

        for rate in rates:
            stat_names.append(rate[1])
            ratelist.append(rate[4])
        dict['names'] = stat_names
        dict['rates'] = ratelist
        return dict


if __name__== '__main__':
    hive = HiveOpreator()
    p = PlotlyOpreator()

    #read data from hive
    chat_dict = hive.read_all_from_hive()
    p.draw_caculate_chat(chat_dict)

    #show map in the plotly
    dict = hive.read_locations_from_hive()
    p.draw_station_map(dict)

    #show the disable rate top 20
    dict = hive.read_usereate_top20_from_hive()
    print(dict)
    p.draw_top20_dis_rate(dict)
