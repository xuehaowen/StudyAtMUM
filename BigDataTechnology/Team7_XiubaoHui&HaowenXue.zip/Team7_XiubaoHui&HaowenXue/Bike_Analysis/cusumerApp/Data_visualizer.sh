#!/bin/bash
#params{path}:/home/cloudera/Project/FinalProject/commands
port=4042
pid=$(netstat -nlp | grep :$port | awk '{print $7}' | awk -F"/" '{ print $1 }');
if [  -n  "$pid"  ];  then
    kill  -9  $pid;
fi

spark-submit --files /etc/hive/conf/hive-site.xml --conf spark.ui.port=4042 $1/src/Bike_SparkSql_From_Hive.py 
