import sys
import json
import time
from pyspark import SparkContext, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql.functions import desc
from pyspark.sql import Row, SQLContext
from pyspark.sql import HiveContext

sc = SparkContext(appName="myProject")
ssc = StreamingContext(sc, 10)

def getHiveContextInstance(sparkContext):
    if ('hiveContextSingletonInstance' not in globals()):
        globals()['hiveContextSingletonInstance'] = HiveContext(sparkContext)
        globals()['hiveContextSingletonInstance'].setConf("hive.metastore.uris", "thrift://127.0.0.1:9083")
    return globals()['hiveContextSingletonInstance']

def store(rdd):
    num_of_record = rdd.count()
    if num_of_record == 0:
       return
    sqlContext = getHiveContextInstance(rdd.context)
    record = sqlContext.createDataFrame(rdd)
    record.write.mode('overwrite').saveAsTable("sharedbikes")
    a = sqlContext.sql('select * from sharedbikes')
    a.show()


dataStream = KafkaUtils.createDirectStream(ssc,['Bike_stream'],{"metadata.broker.list":'localhost:9092'})
processedData = dataStream.map(lambda line: json.loads(line[1].decode('utf-8'))['stations']).flatMap(lambda x: x ).flatMap(lambda x: x.values()).filter(lambda x: x['station_info']['capacity'] > 0).map(lambda x: Row(id=x['station_info']['id'],name=x['station_info']['name'],capacity=x['station_info']['capacity'],lat=x['station_info']['lat'],lon=x['station_info']['lon'],bike_ava=x['station_status']['num_bi_ava'],bike_dis=x['station_status']['num_bi_dis'],dock_dis=x['station_status']['num_do_dis'],dock_ava=x['station_status']['num_do_ava']))
processedData.pprint()
processedData.foreachRDD(store)

ssc.start()
ssc.awaitTermination()
