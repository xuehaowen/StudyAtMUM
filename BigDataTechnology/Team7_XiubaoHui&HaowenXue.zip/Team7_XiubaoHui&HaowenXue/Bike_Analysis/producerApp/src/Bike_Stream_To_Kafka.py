# importing the requests library
import time
import httplib
import json
from kafka import KafkaProducer
URL = "http://gbfs.citibikenyc.com/gbfs/gbfs.json"
#create topic :
#kafka-topics --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic Bike_stream
#kafka-console-consumer --bootstrap-server localhost:9092 --topic Bike_stream --from-beginning
#kafka-console-producer --broker-list localhost: --topic Bike_stream

def send_station_info_to_Kafka(station_info_json):
    producer = KafkaProducer(bootstrap_servers='localhost:9092')
    print("Send stations data to kafka.....")
    producer.send('Bike_stream', station_info_json)
    producer.close()

def request_connection_for_url(url):
    http_url = url.replace("https://","http://")
    conn = httplib.HTTPConnection("gbfs.citibikenyc.com")
    print("Get date from :"+http_url)
    conn.request(method="GET",url=http_url)
    response = conn.getresponse()
    read= response.read()
    res = read.decode('utf-8')
    res_json = json.loads(res)
    return res_json;

def get_data_from_citibike(url):
    res_json = request_connection_for_url(url);
    feeds = res_json['data']['en']['feeds']
    station_info_dict = {}

    for feed in feeds :
        if feed['name']=='station_information':
           info_json = request_connection_for_url(feed['url']);
           stations = info_json['data']['stations']
           for station in stations:
               station_id = station['station_id']
               #print(station_id)
               station_info_dict[station_id]={'id':station['station_id'],'name':station['name'],'lat':station['lat'],'lon':station['lon'],'capacity':station['capacity']};
           print("Got station information:OK")

    for feed in feeds :
        if feed['name']=='station_status':
            print("Starting get status about stations.....")
            while True:
                status_json = request_connection_for_url(feed['url'])
                st_infos = status_json['data']['stations']
                stations = []
                for station in st_infos:
                    station_id = station['station_id']
                    st_info = station_info_dict[station_id]
                    st_status = {'num_bi_ava':station['num_bikes_available'],
                                 'num_bi_dis':station['num_bikes_disabled'],
                                 'num_do_ava':station['num_docks_available'],
                                 'num_do_dis':station['num_docks_disabled']
                                 }
                    station_obj = {station_id:{'station_info':st_info,'station_status':st_status}}
                    stations.append(station_obj)

                #print(stations)
                stations_dict = {'stations':stations}
                time.sleep(10)
                send_station_info_to_Kafka(json.dumps(stations_dict))

# get data from citibile website
get_data_from_citibike(URL)
