#!/bin/bash
#params{path}:/home/cloudera/Project/FinalProject/commands
port=4041
pid=$(netstat -nlp | grep :$port | awk '{print $7}' | awk -F"/" '{ print $1 }');
if [  -n  "$pid"  ];  then
    kill  -9  $pid;
fi

python $1/src/Bike_Stream_To_Kafka.py&
spark-submit --conf spark.ui.port=4041 $1/src/Bike_Stream_To_Hive.py 
