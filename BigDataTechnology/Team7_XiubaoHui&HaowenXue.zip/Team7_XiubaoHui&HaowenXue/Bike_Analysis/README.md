Instructions:
(We integrate all the parts into one project with python, so we have only one project)
This project is designed to monitor the service condition of Citi Bike, which provides an service for residents in NewYork to use shared bikes.

What we can do now:
1.Monitor the station information
2.Monitor the station status
3.Find out the stations with a high bike broken rate:

With the information above:
For manager
1.they can easily make a list of stations with a high broken rate, do some research, find the reason and solve it.
2.they can get the list of overloaded station or low usage station, to decide whether they can set a new station or replace the old one.

For customer
1.they can track the status of the closest station to find whether they can get bike or return bike

Data Flow:
website ->(every 10 sec) python script -> kafka -> spark streaming -> hive -> spark sql -> plotly

Precondition:
Prerequisite:
	For using kafka to send data on python, we have to install kafkautil through pip
	#get pip for python2.6
	curl https://bootstrap.pypa.io/2.6/get-pip.py -o get-pip.py
	#install
	python get-pip.py
	#get appropriate version for python
	pip install kafka-python==1.3.5
We write a python script to read the real-time data from website:gbfs.citibikenyc.com, repackage it and send to kafka every 10 sec.
	step1. Send request to get station information
	step2. Send request to get station status
	step3. Merge into one record
	step4. Send to kafka in json format

Part 1:
Prerequisite:
	For using pyspark-streaming to recieve data from kafka, we have to add dependency to the project
	add dependency with spark-submit
	--packages org.apache.spark:spark-streaming-kafka-0-10-assembly_2.10:2.0.0
We use pyspark-streaming to recieve data from kafka, decode it and write to hive constantly
	step1. Get directStream from kafka
	step2. Use transformation to decode and generate row object in each rdd
	step3. Use foreachRDD to handle each record to write to hive

Part 2:
We pyspark-sql to read data from hive, do some analysis and aggregation, then send the data to differnt interface to display through plotly
	step1. Get dataframe from hive
	step2. Generate 3 lists of data from operation on dataframe
	step3. Call another python script with these list

Part 3: 	
Prerequisite:
	For using mapbox plugin of plotly, we have to upgrade python to at least version 2.7
	version 1.13.0 starts to support python2.7 only and provide a new feature mapbox
	#install plotly
	pip install plotly
We use plotly to display the result of our data processing in 3 kinds of charts: map,bar,grid chart
	step1. Reconstruct the data to match the requirement of plotly
	step2. Use the method provided by plotly

Part 4:
#install kafka
	sudo yum clean all
	sudo yum install kafka
	sudo yum install kafka-server
#check broker.id etc/kafka/conf/server.properties
#start kafka server
	sudo service kafka-server start
We use kafka as a message queue in the middle of two sub systems.
We build it in a simple way, which has only 1 broker and 1 partition

#We record more information about our project in document/env.setup

#Excute setps:
#Warning before run as below,make sure delete the 'sharedbikes' and there is no conflicts about the ports:4041,4042
1.$cd Bike_Analysis/producerApp/src/
	python Bike_Stream_To_Kafka.py
2.$cd Bike_Analysis/producerApp/src/
	spark-submit --conf spark.ui.port=4041 Bike_Stream_To_Hive.py
3.$cd Bike_Analysis/cusumerApp/src/
	spark-submit --files /etc/hive/conf/hive-site.xml --conf spark.ui.port=4042 Bike_SparkSql_From_Hive.py
